import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"

const benefits = [
  "Increase bookings 24/7",
  "Generate more qualified leads",
  "Improve client retention",
  "Collect more positive reviews",
  "Save time with automation",
]

export default function CTA() {
  return (
    <section className="border-t">
      <div className="container py-24 md:py-32">
        <div className="mx-auto grid max-w-5xl gap-12 lg:grid-cols-2">
          <div className="flex flex-col justify-center space-y-4">
            <h2 className="font-bold text-3xl leading-[1.1] sm:text-3xl md:text-4xl">
              Ready to transform your service business?
            </h2>
            <p className="text-muted-foreground sm:text-lg">
              Join hundreds of service-based businesses that have increased their revenue and reduced manual work with
              our AI automation solutions.
            </p>

            <ul className="space-y-2 mt-4">
              {benefits.map((benefit, i) => (
                <li key={i} className="flex items-center">
                  <Check className="mr-2 h-5 w-5 text-primary" />
                  <span>{benefit}</span>
                </li>
              ))}
            </ul>

            <div className="pt-4">
              <Button size="lg">Schedule Your Free Consultation</Button>
            </div>
          </div>

          <div className="rounded-lg border bg-background p-8">
            <h3 className="text-2xl font-bold mb-4">Get Started Today</h3>
            <form className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium mb-1">
                  Business Name
                </label>
                <input
                  type="text"
                  id="name"
                  className="w-full p-2 rounded-md border bg-background"
                  placeholder="Your business name"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium mb-1">
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  className="w-full p-2 rounded-md border bg-background"
                  placeholder="you@example.com"
                />
              </div>
              <div>
                <label htmlFor="businessType" className="block text-sm font-medium mb-1">
                  Business Type
                </label>
                <select id="businessType" className="w-full p-2 rounded-md border bg-background">
                  <option value="">Select business type</option>
                  <option value="salon">Hair Salon/Barbershop</option>
                  <option value="spa">Spa/Wellness</option>
                  <option value="dental">Dental Practice</option>
                  <option value="medical">Medical Practice</option>
                  <option value="fitness">Fitness/Gym</option>
                  <option value="restaurant">Restaurant</option>
                  <option value="other">Other Service Business</option>
                </select>
              </div>
              <Button type="submit" className="w-full">
                Request Demo
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
